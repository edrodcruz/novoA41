export const environment = {
  production: false,
  totvs_url: 'https://totvsapptst.dieboldnixdorf.com.br:8143/api/integracao/aat/v1/apiesaa041',
  totvs_empresa: '1',
  totvs_usuario: 'super',
  totvs_senha: 'prodiebold11'
};
