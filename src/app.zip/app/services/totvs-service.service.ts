import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject, map, take, tap } from 'rxjs';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { PoTableColumn } from '@po-ui/ng-components';



//Endpoint setada no environment
// totvs_url: 'https://totvsapptst.dieboldnixdorf.com.br:8543/api/integracao/

const headersTotvs = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Basic ' + btoa(`${environment.totvs_usuario}:${environment.totvs_senha}`),
      'CompanyId': environment.totvs_empresa
    });
    
@Injectable({
  providedIn: 'root'
})

export class TotvsService {
  private reg!:any;
  _url = environment.totvs_url;

  constructor(private http: HttpClient ) { }

  private emissorEvento$ = new Subject<any>();

  EmitirContadoresRegistros(valor: any) {
    this.emissorEvento$.next(valor);
  }

  public ObterDadosColeta(params?:any){

  }


  ObterContadoresRegistros() {
    return this.emissorEvento$.asObservable();
  }

  //--------------------- INTERPRETADOR RESULTADO DE ERROS/WARNING 
  public tratarErros(mensagem:any):string{
     if (mensagem.messages ==! undefined)
        return mensagem.message
      return '';
  }

 
//------------ Colunas Grid Saldo Terceiro
obterColunasExtraKit(): Array<PoTableColumn> {
  return [
    { property: 'tipo', label: 'Kit' },
    { property: 'nroDocto', label: "Docto" },
    { property: 'serieDocto', label: "Série" },
    { property: 'itCodigo', label: "Item"}, 
    { property: 'qtSaldo', label: 'Qtde', type: 'number', color:"color-10"},
    { property: 'descItem', label: "Descrição", width: '300px'}
   
  ];
}

//------------ Coluna Grid Detalhe
obterColunasTodos(): Array<PoTableColumn> {
  return [
    { property: 'itCodigo', label: "Item"},
    { property: 'descItem', label: "Descrição", width: '300px'},
    { property: 'qtMascara', label: 'Máscara.', type: 'number'},
    { property: 'qtPagar', label: 'Entregar', type: 'number', width: '10%', color:"color-07", visible:true},
    { property: 'qtRenovar', label: 'Renovar', type: 'number', width: '10%', color:"color-10", visible:true},
    { property: 'qtExtrakit', label: 'ET', type: 'number', width: '10%', color:"color-10", visible:true},
    { property: 'qtSaldo', label: 'Saldo', type: 'number'},
    { property: 'codLocaliza', label: "Local"},
    { property: 'kit', label: "Kit"},
    { property: 'itPrincipal', label: "Principal"},
    { property: 'seqOrdem', label: "Ordem"},
  ];
}

obterColunasPagar(): Array<PoTableColumn> {
  return [
    { property: 'itCodigo', label: "Item"},
    { property: 'descItem', label: "Descrição", width: '300px'},
    { property: 'qtMascara', label: 'Máscara', type: 'number'},
    { property: 'qtPagar', label: 'Entregar', type: 'number', color:"color-07", visible:true},
    { property: 'qtSaldo', label: 'Saldo', type: 'number'},
    { property: 'codLocaliza', label: "Local"},
    { property: 'kit', label: "Kit"},
    { property: 'itPrincipal', label: "Principal"},
    { property: 'seqOrdem', label: "Ordem"},
  ];
}

obterColunasRenovar(): Array<PoTableColumn> {
  return [
    { property: 'itCodigo', label: "Item"},
    { property: 'descItem', label: "Descrição", width: '300px'},
    { property: 'qtMascara', label: 'Máscara', type: 'number'},
    { property: 'qtRenovar', label: 'Renovar', type: 'number', color:"color-10", visible:true},
    { property: 'qtSaldo', label: 'Saldo', type: 'number'},
    { property: 'codLocaliza', label: "Local"},
    { property: 'kit', label: "Kit"},
    { property: 'itPrincipal', label: "Principal"},
    { property: 'seqOrdem', label: "Ordem"},
  ];
}

obterColunasExtrakit(): Array<PoTableColumn> {
  return [
    { property: 'itCodigo', label: "Item"},
    { property: 'descItem', label: "Descrição", width: '300px'},
    { property: 'qtMascara', label: 'Máscara', type: 'number'},
    { property: 'qtExtrakit', label: 'ExtraKit', type: 'number', color:"color-10", visible:true},
    { property: 'qtSaldo', label: 'Saldo', type: 'number'},
    { property: 'codLocaliza', label: "Local"},
    { property: 'kit', label: "Kit"},
    { property: 'itPrincipal', label: "Principal"},
    { property: 'seqOrdem', label: "Ordem"},
  ];
}

obterColunasSemSaldo(): Array<PoTableColumn> {
  return [
    { property: 'itCodigo', label: "Item"},
    { property: 'descItem', label: "Descrição", width: '300px'},
    { property: 'qtMascara', label: 'Máscara', type: 'number'},
    { property: 'qtPagar', label: 'Não Atendida', type: 'number', color:"color-08", visible:true},
    { property: 'qtSaldo', label: 'Saldo', type: 'number'},
    { property: 'kit', label: "Kit"},
  ];
}

  //---------------------- COMBOBOX ESTABELECIMENTOS
  //Retorno transformado no formato {label: xxx, value: yyyy}
  public ObterEstabelecimentos(params?: any){
    return this.http.get<any>(`${this._url}/ObterEstab`, {params: params, headers:headersTotvs})
                 .pipe(
                        //tap(data => {console.log("Retorno API TOTVS => ", data)}),
                        map(item => { return item.items.map((item:any) =>  { return { label:item.codEstab + ' ' + item.nome, value: item.codEstab, codFilial: item.codFilial } }) }),
                        ///tap(data => {console.log("Data Transformada pelo Map =>", data)}),
                        take(1)
                      );
  }

  //---------------------- COMBOBOX TECNICOS
  /*Retorno transformado no formato {label: xxx, value: yyyy}*/
  public ObterEmitentesDoEstabelecimento(id:string){
    return this.http.get<any>(`${this._url}/ObterTecEstab?codEstabel=${id}`, {headers:headersTotvs})
                 .pipe(
                  map(item => { return item.items.map((item:any) =>  { return { label: item.codTec + ' ' + item.nomeAbrev, value: item.codTec  } }) }),
                  ///tap(data => {console.log("Data Transformada pelo Map =>", data)}),
                  take(1));
  }

  //---------------------- COMBOBOX TRANSPORTES
  /*Retorno transformado no formato {label: xxx, value: yyyy}*/
  public ObterTransportadoras(){
    return this.http.get<any>(`${this._url}/ObterTransp`, {headers:headersTotvs})
                 .pipe(
                  map(item => { return item.items.map((item:any) =>  { return { label: item.codTransp + ' ' + item.nomeAbrev, value: item.codTransp  } }) }),
                  ///tap(data => {console.log("Data Transformada pelo Map =>", data)}),
                  take(1));
  }

  //---------------------- COMBOBOX ENTREGA
  /*Retorno transformado no formato {label: xxx, value: yyyy}*/
  public ObterEntrega(param:any){
    return this.http.get<any>(`${this._url}/ObterEntrega?codTecnico=${param.codTecnico}&codEstabel=${param.codEstabel}`, {headers:headersTotvs})
                 .pipe(
                  map(item => { return {
                                  nrProcesso: item.nrProcesso, 
                                  listaEntrega: item.listaEntrega.map((x:any) =>  { return { 
                                    
                                         label: x.codEntrega, 
                                         value: x.codEntrega,
                                         cidade: x.nomeAbrev 
                                  }})}}),
                  take(1))
  }

  
  //---------------------- GRID EXTRAKIT 
  public ObterExtraKit(params?: any){
    return this.http.post(`${this._url}/ObterExtrakit`, params, {headers:headersTotvs})
                   .pipe(take(1));
  }
    
  //---------------------- Resumo 
  public PrepararResumo(params?: any){
    return this.http.post(`${this._url}/PrepararCalculo`, params, {headers:headersTotvs})
                   .pipe(take(1));
  }

  //---------------------- Login 
  public LoginAlmoxarifado(params?: any){
    return this.http.post(`${this._url}/LoginAlmoxa`, params, {headers:headersTotvs})
                   .pipe(take(1));
  }
  
}
